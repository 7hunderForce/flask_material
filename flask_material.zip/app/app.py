import config

from flask import Flask, render_template, redirect, url_for, send_file, send_from_directory, request, session, Response, make_response, jsonify

#==========================================================================================================
# APP INITIALIZE
#==========================================================================================================
app = Flask(__name__, static_folder='static', template_folder='template')
app.secret_key = config.SECRET_KEY

@app.route('/')
def index():
    return render_template('dashboard.html') 


@app.route('/billing/')
def billing():
    return render_template('billing.html') 

@app.route('/notifications/')
def notifications():
    return render_template('notifications.html') 

@app.route('/profile/')
def profile():
    return render_template('profile.html')     

@app.route('/login/')
def login():
    return render_template('login.html') 

@app.route('/register/')
def register():
    return render_template('register.html') 

@app.route('/tables/')
def tables():
    return render_template('tables.html') 

@app.route('/virtual-reality/')
def vr():
    return render_template('virtual-reality.html') 


#=============================================================================================================
# MAIN
#=============================================================================================================
if __name__ == '__main__':
    app.run(host='0.0.0.0', port='8080', debug=True, threaded=True)